
#ifndef MACCHINA_CONFIG_H_
#define MACCHINA_CONFIG_H_

//#define FW_TEST


//#define CFG_MACCHINA_M2
#define CFG_MACCHINA_A0
//#define CFG_MACCHINA_ESP32_TEST

#endif