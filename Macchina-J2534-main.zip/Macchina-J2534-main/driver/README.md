# Building the driver

## Windows
run `.\build.bat`. This will build and install the driver, then will apply the necessary registry entries

## Linux
run `./build.sh`. This will build the driver and copy it, and the JSON to `~/.passthru/`